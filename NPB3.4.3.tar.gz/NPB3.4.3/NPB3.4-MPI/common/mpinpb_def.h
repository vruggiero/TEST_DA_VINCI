      use mpi
      implicit none
!     include 'mpif.h'

      integer comm_out
      integer comm_in
