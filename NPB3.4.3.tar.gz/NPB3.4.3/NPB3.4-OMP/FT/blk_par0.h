      integer fftblock_default, fftblockpad_default
      parameter (fftblock_default=0,  &
     &           fftblockpad_default=fftblock_default+2)
      
